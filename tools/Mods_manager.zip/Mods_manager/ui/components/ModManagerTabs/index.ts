export { ModManagerTabs } from "./ModManagerTabs";
