export { GameConfigPanel } from "./GameConfigPanel";
